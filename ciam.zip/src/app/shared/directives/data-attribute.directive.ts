import {Directive, ElementRef, Renderer, Input} from '@angular/core';

@Directive({
  selector: '[dataAttribute]'
})
export class DataAttributeDirective {

  // #TODO add ability to setAttribute
  private dataAttributeName: string;
  private dataAttributeValue: any;

  constructor(private el: ElementRef, private renderer: Renderer) {}

  @Input() set dataAttribute(attributeValue: string) {
    this.dataAttributeValue = attributeValue;
    this.el.nativeElement.setAttribute('bond', JSON.stringify(attributeValue).toString());
  }

  setAttribute(attributeName: string, attributeValue: string) {
    this.renderer.setElementAttribute(this.el.nativeElement, attributeName, attributeValue)
  }

}
