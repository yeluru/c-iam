import '../styles/styles.scss';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';
import { SignaturePadModule } from 'angular2-signaturepad';
import { SignatureFieldComponent } from './signature-field/signature-field.component';

// Observable operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import 'rxjs/add/operator/first';
import 'rxjs/add/operator/toPromise';

import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

import {HttpModule} from '@angular/http';
import {AppComponent} from './app.component';
import {FmHeaderComponent} from './fannie-mae-cdx-components/fm-header/fm-header.component';
import {FmToolbarComponent} from './fannie-mae-cdx-components/fm-toolbar/fm-toolbar.component';
import {FmSelectComponent} from './fannie-mae-cdx-components/fm-select/fm-select.component';

import {KeysPipe} from './shared/pipes/keys.pipe';

import {DataAttributeDirective} from './shared/directives/data-attribute.directive';
import {LocationStrategy, HashLocationStrategy} from "@angular/common";



@NgModule({
    declarations: [
      AppComponent,
      FmHeaderComponent,
      FmToolbarComponent,
      FmSelectComponent,
      KeysPipe,
      DataAttributeDirective,
        SignatureFieldComponent
    ],
    imports: [
      BrowserModule,
      FormsModule,
      HttpModule,
      ReactiveFormsModule,
        SignaturePadModule
    ],
    providers: [{provide: LocationStrategy, useClass: HashLocationStrategy}],
    bootstrap: [AppComponent]

})
export class AppModule {
}
