import {Component, OnInit, Input, EventEmitter} from '@angular/core';
import {FormBuilder, Validators, ValidatorFn} from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import {Output} from "@angular/core/src/metadata/directives";

@Component({
  selector: 'investor-direct-fm-input-cusip',
  templateUrl: './fm-input-cusip.component.html',
  styleUrls: ['./fm-input-cusip.component.scss']
})
export class FmInputCusipComponent implements OnInit {

  //user input request type: eg(single family remic, smbs etc.)
  @Input() requestType:string;
  @Output() onDealSearch = new EventEmitter<any>();

  usrInput:string;

  hint: string;

  form: FormGroup;

  isSearchBtnEnable: boolean = false;

  //for demo use only
  mDealSubType:string = "SFREMIC";

  constructor(public fb: FormBuilder) { }

  ngOnInit() {
    this.form = this.fb.group({
      dealNbr: new FormControl('', [Validators.required, this.validateSearchNo()])
    });
  }

  ngOnChanges(){
    this.validateSearchNo();
    this.updateHintText();
  }

  private dealSearch(): void {
    this.onDealSearch.emit({dealSubType: this.mDealSubType, userSearchInput: this.usrInput});
    if (!this.form.get('dealNbr').invalid) {
      this.onDealSearch.emit({dealSubType: this.mDealSubType, userSearchInput: this.usrInput});
      console.log(":::send request", this.mDealSubType, this.usrInput);
    }

  }

  private validateSearchNo(): ValidatorFn {
    function isEmptyInputValue(value: any) {
      return value == null || typeof value === 'string' && value.length === 0;
    }

    return (control: FormControl): {[key: string]: boolean} => {

      if (isEmptyInputValue(control.value)) {
        return null;
      }

      console.log(":::input text:::", this.usrInput);

      let cusipRegex = new RegExp("^[a-zA-Z0-9]{9}$");
      if (this.requestType === 'Single Family REMIC') {
        this.mDealSubType = "SFREMIC";

        let dealRegex = new RegExp("^[0-9]{4}[-][0][0-9]{2}$");
        if (dealRegex.test(control.value) || cusipRegex.test(control.value)) {
          console.log(":::SF-Remic Passed Validation:::", control.value);
          this.isSearchBtnEnable = true;
          return {sfRemicError: false};
        } else {
          console.log(":::SF-Remic Failed Validation:::", control.value);
          this.isSearchBtnEnable = false;
          return {sfRemicError: true};
        }
      } else if(this.requestType === 'SMBS'){
        this.mDealSubType = "SMBS";
        let dealRegex = new RegExp("^[0-9]{3}$");
        if (dealRegex.test(control.value) || cusipRegex.test(control.value)) {
          console.log(":::SMBS Passed Validation:::", control.value);
          this.isSearchBtnEnable = true;
          return {smbsError: false};
        } else {
          return {smbsError: true}
        }
      }else if(this.requestType === 'Multi Family REMIC'){
        this.mDealSubType = "MFREMIC";
        let dealRegex = new RegExp("^[0-9]{4}[-][M][0-9]{2}$");
        if (dealRegex.test(control.value) || cusipRegex.test(control.value)) {
          console.log(":::mf-Remic Passed Validation:::", control.value);
          this.isSearchBtnEnable = true;
          return {mfRemicError: false};
        } else {
          console.log(":::mf-Remic Failed Validation:::", control.value);
          this.isSearchBtnEnable = false;
          if(this.usrInput){
            if(this.usrInput.length > 3) {
              return {mfRemicError: true};
            }else{
              return {mfRemicError: false};
            }
          }
        }
      }else if(this.requestType === 'Benchmark REMIC'){
        this.mDealSubType = "BMREMIC";
        let dealRegex = new RegExp("^[0-9]{4}[-][B][0-9]{2}$");
        if (dealRegex.test(control.value) || cusipRegex.test(control.value)) {
          console.log(":::bm-Remic Passed Validation:::", control.value);
          this.isSearchBtnEnable = true;
          return {bmRemicError: false};
        } else {
          console.log(":::bm-Remic Failed Validation:::", control.value);
          this.isSearchBtnEnable = false;
          if(this.usrInput){
            if(this.usrInput.length > 3) {
              return {bmRemicError: true};
            }else{
              return {bmRemicError: false};
            }
          }
        }
      }else{
        this.isSearchBtnEnable = false;
      }
    }
  }

  private updateHintText(): void {
    if(this.requestType != null){

      switch(this.requestType){
        //single family remic
        case "Single Family REMIC":{
          this.hint = "Enter Deal(ex.2016-001) or CUSIP";
          break;
        }
        //smbs
        case "SMBS":{
          this.hint = "Enter Turst (ex. 100) or CUSIP";
          break;
        }
        //multifamily remic
        case "Multi Family REMIC":{
          this.hint = "Enter Deal (ex.2016-M01) or CUSIP";
          break;
        }
        //benchmark remic
        case "Benchmark REMIC":{
          this.hint = "Enter Deal (ex.2016-B01) or CUSIP";
          break;
        }
        default:{
          this.hint = "Enter Deal No.(ex.2016-74) or CUSIP";
          break;
        }
      }

      this.isSearchBtnEnable = false;
    }
  }

  // private doSearch(event) {
  //   console.log(event);
  //   console.log(this.searchForm.value);
  // }

}
