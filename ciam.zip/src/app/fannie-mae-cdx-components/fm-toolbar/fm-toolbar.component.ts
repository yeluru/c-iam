import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fm-toolbar',
  templateUrl: './fm-toolbar.component.html',
  styleUrls: ['./fm-toolbar.component.scss']
})
export class FmToolbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
