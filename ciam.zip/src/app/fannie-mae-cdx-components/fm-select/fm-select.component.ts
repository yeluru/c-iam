import {Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'fm-select',
  templateUrl: './fm-select.component.html',
  styleUrls: ['./fm-select.component.scss']
})
export class FmSelectComponent implements OnInit {

  /**
   *  Whether to have split button (drop-down arrow) or button inline
   */
  @Input()
  displaySplitButton: boolean;
  /**
   *   Data array for the chart, each item of the array will be single 'pie'
   */
  @Input()
  selectItems: Array<string>;

  constructor() { }

  ngOnInit() {
  }

}
