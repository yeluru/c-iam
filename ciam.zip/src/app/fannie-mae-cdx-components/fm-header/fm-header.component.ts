import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fm-header',
  templateUrl: './fm-header.component.html',
  styleUrls: ['./fm-header.component.scss']
})
export class FmHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
