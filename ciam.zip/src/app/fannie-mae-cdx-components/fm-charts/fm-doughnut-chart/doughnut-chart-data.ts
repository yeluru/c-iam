/**
 *  Doughnut chart data structure
 */
export class DoughnutChartData {
  /**
   *  Count for this section of the 'pie'
   */
  count: number;
  /**
   *   Text to display in the legend
   */
  legendText: string;
  /**
   *  Color of this section in the 'pie'
   */
  pieColor: string

  constructor(count: number, legendText: string, pieColor: string){
    this.count = count;
    this.legendText = legendText;
    this.pieColor = pieColor;
  }
}
