import {Component, ViewChild, Input, OnInit, AfterContentInit} from '@angular/core';
import {DoughnutChartData} from "./doughnut-chart-data";

/**
 *   Doughnut chart component - This component is based on 'ChartJS' library
 *
 *   We display a doughnut chart with 'Title' on top and 'Legend' on right side
 *
 *   Takes two 'input' params
 *        - chartTitle
 *        - chartData
 *              - count: number of items for each pie of the whole circle
 *              - legendText: text to be displayed for legend
 *              - pieColor: pie color for each section
 *
 */

/**
 *  Variable for Chart from ChartJS
 */
declare var Chart: any;

@Component({
  selector: 'investor-direct-fm-doughnut-chart',
  templateUrl: './fm-doughnut-chart.component.html',
  styleUrls: ['./fm-doughnut-chart.component.scss']
})
export class FmDoughnutChartComponent implements OnInit {

  /**
   *  Get 'canvas' of the chart from template
   */
  // get the element with the #chartCanvas on it
  @ViewChild("chartCanvas") chartCanvas;

  /**
   *  Chart title
   */
  @Input()
  chartTitle: string;

  /**
   *   Data array for the chart, each item of the array will be single 'pie'
   */
  @Input()
  chartData: Array<DoughnutChartData>;

  constructor() {}

  ngOnInit() {

    // Get context of the chart
    var ctx = (<HTMLCanvasElement>this.chartCanvas.nativeElement).getContext("2d");

    //debug for title
    console.log(this.chartTitle);

    //local variables for chartJS options input
    var data = [];
    var colors = [];
    var totalCount = 0;

    // filter data from the input, so we can feed to chartJS options
    this.chartData.forEach((item) => {
      //debug
      console.log(item.count);

      //prepare data for ChartJS
      data.push(item.count);
      colors.push(item.pieColor);

      totalCount += item.count;
    });

  //Doughnut chart configuration
    var config = {
      type: 'doughnut',
      data: {
        datasets: [{
          data: data, // feed count from 'input'
          backgroundColor: colors, // feed color for each pie that we received from 'input'
          borderWidth: 0
        }],
        labels: []
      },
      options: {
        responsive: false,
        cutoutPercentage: 80,
        // onAnimationComplete: this.addText(ctx, totalCount),
        animation: {
          animateScale: true,
          animateRotate: true
        }
      }
    };

    //create 'doughnut' chart with above options
    new Chart(ctx, config);

  }

  // private addText(ctx: CanvasRenderingContext2D,totalCount: number){
  //
  //   //setting center text
  //   var cx = this.chartCanvas.nativeElement.width / 2;
  //   var cy = this.chartCanvas.nativeElement.height / 2;
  //
  //   ctx.textAlign = 'center';
  //   ctx.textBaseline = 'middle';
  //   ctx.font = '14px';
  //   ctx.fillStyle = 'white';
  //   console.log("--------", totalCount.toString());
  //   console.log("--------", cx);
  //   console.log("--------", cy);
  //   ctx.fillText(totalCount.toString(), cx, cy);
  // }

}
