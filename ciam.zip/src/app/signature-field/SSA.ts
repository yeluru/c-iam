export class SSA {
    constructor(
        public name: string,
        public address: string,
        public SSN: number,
        public Email: string,
        public Signature: string,
        public agreeForTerms: boolean
    ) {  }
}