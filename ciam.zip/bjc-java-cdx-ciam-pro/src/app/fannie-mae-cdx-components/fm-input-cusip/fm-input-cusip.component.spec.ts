/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { FmInputCusipComponent } from './fm-input-cusip.component';

describe('FmInputCusipComponent', () => {
  let component: FmInputCusipComponent;
  let fixture: ComponentFixture<FmInputCusipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FmInputCusipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FmInputCusipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
