import {Component, OnInit, ViewEncapsulation, Input, Output, ElementRef, EventEmitter} from '@angular/core';
import * as Pikaday from 'pikaday';

@Component({
  selector: 'fm-date-picker',
  templateUrl: './fm-date-picker.component.html',
  styleUrls: ['./fm-date-picker.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FmDatePickerComponent implements OnInit {

  @Input() classNames: string;
  @Input() datePickerId: string;
  @Input() placeholderText: string;
  @Input() dateValue: string = "";
  @Output() dateValueChange = new EventEmitter();

  private el: ElementRef;

  constructor(el: ElementRef) {
    this.el = el;
  }

  ngOnInit():void {
    let inputElement: HTMLElement = this.el.nativeElement.children[0];
    inputElement.setAttribute("id", this.datePickerId);
    new Pikaday({field: inputElement, format: 'MM/DD/YYYY'});
  }

  dateSelected(selectedDate) {
    console.log(selectedDate);
    this.dateValueChange.emit(selectedDate);
  }

  @Input()
  set datePickerValue(dateValue: string) {
    this.dateValue = dateValue;
  }


}
